#include <GLFW/glfw3.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <cmath>

using namespace std;

const float DEG2RAD = 3.14159f / 180.0f;

void processInput(GLFWwindow* window);

// --------------------------------------------------
// GLOBAL STATE
// --------------------------------------------------

bool spacePressedLastFrame = false;

// --------------------------------------------------
// BRICK CLASS (ENHANCED)
// --------------------------------------------------

class Brick
{
public:
    float red, green, blue;
    float x, y, width;
    bool active = true;

    Brick(float xx, float yy, float w, float r, float g, float b)
    {
        x = xx;
        y = yy;
        width = w;
        red = r;
        green = g;
        blue = b;
    }

    void draw()
    {
        if (!active) return;

        float half = width / 2;

        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);
        glVertex2f(x - half, y - half);
        glVertex2f(x + half, y - half);
        glVertex2f(x + half, y + half);
        glVertex2f(x - half, y + half);
        glEnd();
    }
};

// --------------------------------------------------
// PADDLE CLASS
// --------------------------------------------------

class Paddle
{
public:
    float x = 0.0f;
    float y = -0.85f;
    float width = 0.4f;
    float height = 0.05f;

    void draw()
    {
        glColor3f(1.0f, 1.0f, 1.0f);
        glBegin(GL_POLYGON);
        glVertex2f(x - width / 2, y - height / 2);
        glVertex2f(x + width / 2, y - height / 2);
        glVertex2f(x + width / 2, y + height / 2);
        glVertex2f(x - width / 2, y + height / 2);
        glEnd();
    }
};

Paddle paddle;

// --------------------------------------------------
// BALL CLASS (ENHANCED)
// --------------------------------------------------

class Circle
{
public:
    float x, y;
    float dx, dy;
    float radius;
    float red, green, blue;
    bool active = true;

    Circle(float xx, float yy, float r, float rr, float gg, float bb)
    {
        x = xx;
        y = yy;
        radius = r;
        red = rr;
        green = gg;
        blue = bb;
        dx = 0.01f;
        dy = 0.01f;
    }

    void move()
    {
        if (!active) return;

        x += dx;
        y += dy;

        if (x - radius <= -1.0f || x + radius >= 1.0f)
            dx = -dx;

        if (y + radius >= 1.0f)
            dy = -dy;

        if (y - radius <= -1.0f)
        {
            x = 0.0f;
            y = -0.7f;
        }
    }

    void paddleCollision(Paddle& p)
    {
        if (!active) return;

        if (x > p.x - p.width / 2 &&
            x < p.x + p.width / 2 &&
            y - radius <= p.y + p.height / 2 &&
            y - radius >= p.y)
        {
            dy = -dy;
        }
    }

    void brickCollision(vector<Brick>& bricks)
    {
        if (!active) return;

        for (auto& b : bricks)
        {
            if (!b.active) continue;

            float half = b.width / 2;

            if (x > b.x - half && x < b.x + half &&
                y > b.y - half && y < b.y + half)
            {
                dy = -dy;
                b.active = false;
                break;
            }
        }
    }

    void draw()
    {
        if (!active) return;

        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);

        for (int i = 0; i < 360; i++)
        {
            float rad = i * DEG2RAD;
            glVertex2f(cos(rad) * radius + x,
                sin(rad) * radius + y);
        }

        glEnd();
    }
};

// --------------------------------------------------
// GLOBAL OBJECTS
// --------------------------------------------------

vector<Circle> balls;
vector<Brick> bricks;

// --------------------------------------------------
// COLLISION
// --------------------------------------------------

bool CircleCollision(Circle& a, Circle& b)
{
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    float dist = dx * dx + dy * dy;
    float r = a.radius + b.radius;
    return dist <= r * r;
}

// --------------------------------------------------
// CHECK WIN
// --------------------------------------------------

bool allBricksDestroyed()
{
    for (auto& b : bricks)
        if (b.active) return false;
    return true;
}

// --------------------------------------------------
// INPUT
// --------------------------------------------------

void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE))
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_LEFT))
        paddle.x -= 0.03f;

    if (glfwGetKey(window, GLFW_KEY_RIGHT))
        paddle.x += 0.03f;

    if (paddle.x < -0.8f) paddle.x = -0.8f;
    if (paddle.x > 0.8f) paddle.x = 0.8f;

    bool space = glfwGetKey(window, GLFW_KEY_SPACE);

    if (space && !spacePressedLastFrame)
    {
        balls.push_back(
            Circle(paddle.x,
                paddle.y + 0.06f,
                0.05f,
                (float)rand() / RAND_MAX,
                (float)rand() / RAND_MAX,
                (float)rand() / RAND_MAX));
    }

    spacePressedLastFrame = space;
}

// --------------------------------------------------
// MAIN
// --------------------------------------------------

int main()
{
    srand((unsigned)time(NULL));

    if (!glfwInit()) return -1;

    GLFWwindow* window =
        glfwCreateWindow(480, 480, "Enhanced Brick Breaker", NULL, NULL);

    if (!window) return -1;

    glfwMakeContextCurrent(window);

    // bricks
    for (int r = 2; r <= 4; r++)
    {
        for (int c = -4; c <= 4; c++)
        {
            bricks.push_back(
                Brick(c * 0.22f,
                    r * 0.15f,
                    0.18f,
                    1.0f, 0.5f, 0.3f));
        }
    }

    balls.push_back(
        Circle(0.0f, -0.7f, 0.05f,
            1.0f, 0.2f, 0.7f));

    while (!glfwWindowShouldClose(window))
    {
        glClear(GL_COLOR_BUFFER_BIT);

        processInput(window);

        for (auto& b : balls)
        {
            b.move();
            b.paddleCollision(paddle);
            b.brickCollision(bricks);
        }

        // ball-ball collision
        for (size_t i = 0; i < balls.size(); i++)
        {
            for (size_t j = i + 1; j < balls.size(); j++)
            {
                if (CircleCollision(balls[i], balls[j]))
                {
                    balls[i].active = false;
                    balls[j].active = false;
                }
            }
        }

        // cleanup
        balls.erase(remove_if(balls.begin(), balls.end(),
            [](Circle& c) { return !c.active; }), balls.end());

        bricks.erase(remove_if(bricks.begin(), bricks.end(),
            [](Brick& b) { return !b.active; }), bricks.end());

        for (auto& b : bricks) b.draw();
        for (auto& b : balls) b.draw();

        paddle.draw();

        if (allBricksDestroyed())
        {
            cout << "YOU WIN!\n";
            glfwSetWindowShouldClose(window, true);
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}
