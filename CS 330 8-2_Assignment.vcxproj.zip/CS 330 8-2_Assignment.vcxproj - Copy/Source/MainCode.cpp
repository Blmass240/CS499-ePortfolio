#include <GLFW\glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>

using namespace std;

const float DEG2RAD = 3.14159 / 180.0f;

void processInput(GLFWwindow* window);

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

bool spacePressedLastFrame = false;

//BRICK CLASS
class Brick
{
public:
	float red, green, blue;
	float x, y, width;
	BRICKTYPE brick_type;
	ONOFF onoff;

	Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb)
	{
		brick_type = bt; x = xx; y = yy, width = ww; red = rr, green = gg, blue = bb;
		onoff = ON;
	}

	void drawBrick()
	{
		if (onoff == OFF)
			return;

		float half = width /2;

		glColor3f(red, green, blue);
		glBegin(GL_POLYGON);
		glVertex2f(x - half, y - half);
		glVertex2f(x + half, y - half);
		glVertex2f(x + half, y + half);
		glVertex2f(x - half, y + half);
		glEnd();

		}

};

// PADDLE CLASS
class Paddle
{
public:
	float x = 0.0f;
	float y = -0.85f;
	float width = 0.4f;
	float height = 0.05f;

	void draw()
	{
		glColor3f(1.0f, 1.0f, 1.0f);
		glBegin(GL_POLYGON);
		glVertex2f(x - width / 2, y - height / 2);
		glVertex2f(x + width / 2, y - height / 2);
		glVertex2f(x + width / 2, y + height / 2);
		glVertex2f(x - width / 2, y + height / 2);
		glEnd();
	}
};

Paddle paddle;

//BALL CLASS
class Circle
{
public:
	float red, green, blue;
	float radius;
	float x;
	float y;
	float dx, dy;

	Circle(float xx, float yy, float rad, float r, float g, float b)
	{
		x = xx;
		y = yy;
		radius = rad;
		red = r;
		green = g;
		blue = b;
		dx = 0.01f;
		dy = 0.01f;
	}

	void Move()
	{
		x += dx;
		y += dy;

		// Left / Right walls
		if (x - radius <= -1.0f || x + radius >= 1.0f)
			dx = -dx;

		// Top wall (bounce)
		if (y + radius >= 1.0f)
			dy = -dy;

		// Bottom wall (lose/reset)
		if (y - radius <= -1.0f)
		{
			x = 0.0f;
			y = -0.7f; // reset near paddle
			dx = 0.01f;
			dy = 0.01f;
		}
	}

	

	

	void CheckPaddleCollision(Paddle* paddle)
	{
		if (x > paddle->x - paddle->width / 2 &&
			x < paddle->x + paddle->width / 2 &&
			y + radius > paddle->y - paddle->height / 2 &&
			y - radius < paddle->y + paddle->height / 2)
		{
			dy = -dy;

			float hitPos = (x - paddle->x) / (paddle->width / 2);
			dx = hitPos * 0.02f;
		}
	}

	void CheckBrickCollision(vector<Brick>& bricks)
	{
		for (int i = 0; i < bricks.size(); i++)
		{
			if (bricks[i].onoff == OFF)
				continue;

			float half = bricks[i].width / 2;

			if (x > bricks[i].x - half &&
				x < bricks[i].x + half &&
				y > bricks[i].y - half &&
				y < bricks[i].y + half)
			{
				dy = -dy;
				bricks[i].onoff = OFF;

				// Change all bricks' colors when any brick is hit
				for (int j = 0; j < bricks.size(); j++)
				{
					bricks[j].red = (float)rand() / RAND_MAX;
					bricks[j].green = (float)rand() / RAND_MAX;
					bricks[j].blue = (float)rand() / RAND_MAX;
				}

				break; // stop checking other bricks this frame
			}
		}
	}


	void Draw()
	{
		glColor3f(red, green, blue);
		glBegin(GL_POLYGON);
		for (int i = 0; i < 360; i++) {
			float degInRad = i * DEG2RAD;
			glVertex2f(cos(degInRad) * radius + x, sin(degInRad) * radius + y);
		}
		glEnd();
	}
};


vector<Circle> balls;
vector<Brick> bricks;

void CheckCircleCollisions(vector<Circle>& circles)
{
	for (size_t i = 0; i < circles.size(); i++)
	{
		for (size_t j = i + 1; j < circles.size(); j++)
		{
			float dx = circles[j].x - circles[i].x;
			float dy = circles[j].y - circles[i].y;
			float distance = sqrt(dx * dx + dy * dy);

			if (distance < circles[i].radius + circles[j].radius)
			{
				// Both disappear
				circles.erase(circles.begin() + j);
				circles.erase(circles.begin() + i);
				i--;
				j--;
				break;
			}
		}
	}

}

bool AllBricksDestroyed(vector<Brick>& bricks)
{
	for (int i = 0; i < bricks.size(); i++)
	{
		if (bricks[i].onoff == ON)
			return false;
	}
	return true;
}
// Check if two circles collide
bool CircleCollision(Circle& a, Circle& b) {
	float dx = a.x - b.x;
	float dy = a.y - b.y;
	float distanceSquared = dx * dx + dy * dy;
	float radiusSum = a.radius + b.radius;
	return distanceSquared <= radiusSum * radiusSum;
}


int main() {
	srand(time(NULL));

	if (!glfwInit()) {
		return -1;
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
	GLFWwindow* window = glfwCreateWindow(480, 480, "8-2 Assignment", NULL, NULL);
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);

	// Brick grid
	for (int row = 2; row <= 4; row++)
	{
		for (int col = -4; col <= 4; col++)
		{
			bricks.push_back(
				Brick(DESTRUCTABLE,
					col * 0.22f,
					row * 0.15f,
					0.18f,
					1.0f - (row * -0.1f),
					0.5f,
					0.3f));
		}
	}

	balls.push_back(
		Circle(0.0f, -0.7f, 0.05f,
			(float)rand() / RAND_MAX,
			(float)rand() / RAND_MAX,
			(float)rand() / RAND_MAX));

	while (!glfwWindowShouldClose(window))
	{
		glClear(GL_COLOR_BUFFER_BIT);

		processInput(window);

		for (int i = 0; i < balls.size(); i++)
		{
			balls[i].Move();
			balls[i].CheckPaddleCollision(&paddle);
			balls[i].CheckBrickCollision(bricks);
		}

		// ---- NEW: Ball vs Ball collision removal ----
		for (int i = 0; i < balls.size(); i++) {
			for (int j = i + 1; j < balls.size(); j++) {
				if (CircleCollision(balls[i], balls[j])) {
					balls.erase(balls.begin() + j);
					balls.erase(balls.begin() + i);
					i--;
					break;
				}
			}
		}

		for (int i = 0; i < bricks.size(); i++)
			bricks[i].drawBrick();

		// Draw balls
		for (int i = 0; i < balls.size(); i++)
			balls[i].Draw();

		// Win condition
		if (AllBricksDestroyed(bricks))
		{
			cout << "YOU WIN! All bricks destroyed!" << endl;
			glfwSetWindowShouldClose(window, true);
		}

		paddle.draw();

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwTerminate();
	return 0;
}


void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
		paddle.x -= 0.03f;

	if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
		paddle.x += 0.03f;
			
	// Space key to spawn a new ball
	bool spaceCurrentlyPressed = (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS);

	if (spaceCurrentlyPressed && !spacePressedLastFrame)
	{
		// Spawn a new ball at paddle position
		balls.push_back(
			Circle(paddle.x, paddle.y + paddle.height / 2 + 0.05f, 0.05f,  // just above paddle
				(float)rand() / RAND_MAX,
				(float)rand() / RAND_MAX,
				(float)rand() / RAND_MAX)
		);
	}

	// Update last frame state
	spacePressedLastFrame = spaceCurrentlyPressed;

}
