public class Pet {

	// Variable for Pet Class
	private static String petType;
	private static String petName;
	private static int petAge;
	private static boolean dogSpace;
	private static boolean catSpace;
	private static int daysStay;
	private static double amountDue;
	
	// Constructor 
	public Pet() {
		petAge = 0;
		petName = "";
		petType = "";
		dogSpace = false;
		catSpace = false;
		amountDue = 0;
		daysStay = 0;
	}
	
	// Constructor to initialize variables
	public Pet(String type, String name, int age, boolean dog, boolean cat, int stay, double amount) {
		petType = type;
		petName = name;
		petAge = age;
		dogSpace = dog;
		catSpace = cat;
		daysStay = stay;
		amountDue = amount;
	}
	// Setters for Pet class attributes
	public static void setPetType(String type) {
		petType = type;
	}
	public static void setPetName(String name) {
		petName = name;
	}
	public static void setPetAge(int age) {
		petAge = age;
	}
	public static void setDogSpace(boolean dog) {
		dogSpace = dog;
	}
	public static void setCatSpace(boolean cat) {
		catSpace = cat;
	}
	public static void setDaysStay(int stay) {
		daysStay = stay;
	}
	public static void setAmountDue(double amount) {
		amountDue = amount;
	}
	
	// Getters for Pet class Attributes
	public static String getPetType() {
		return petType;
	}
	public static String getPetName() {
		return petName;
	}
	public static int getPetAge() {
		return petAge;
	}
	public static boolean getDogSpace() {
		return dogSpace;
	}
	public static boolean getCatSpace() {
		return catSpace;
	}
	public static int daysStay() {
		return daysStay;
	}
	public static double getAmountDue() {
		return amountDue;
	}
	
	// UML diagram methods
	public static void checkIn() {
	
	}
	public static void checkOut() {
		
	}
	public static void getPet() {
		
	}
	public static void createPet() {
		
	}
	public static void updatePet() {
			
	}
}
