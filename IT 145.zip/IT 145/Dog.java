package Dogjava;

public class Dog {
	// Attributes 
	private int dogSpaceNumber;
	private double dogWeight;
	private boolean grooming;

	// Constructor 
	public Dog() {

	}
	// getter method
	public int getDogSpaceNumber() {
		return dogSpaceNumber;
	}
	// setter method
	public void setDogSpaceNumber(int dogSpaceNumber) {
		this.dogSpaceNumber = dogSpaceNumber;
	}
	// getter method
	public double getDogWeight() {
		return dogWeight;
	}
	//setter method
	public void setDogWeight(double dogWeight) {
		this.dogWeight = dogWeight;
	}
	// getter method
	public boolean getGrooming() {
		return grooming;
	}
	// setter method
	public void setGrooming(boolean grooming ) {
		this.grooming = grooming;
	}
	//end
}
