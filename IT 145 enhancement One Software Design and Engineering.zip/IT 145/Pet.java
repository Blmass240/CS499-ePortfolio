public class Pet {

    // Instance variables (NO STATIC — fixed OOP design flaw)
    private String petType;
    private String petName;
    private int petAge;
    private int daysStay;
    private double amountDue;

    // Constructor
    public Pet() {
        this.petType = "";
        this.petName = "";
        this.petAge = 0;
        this.daysStay = 0;
        this.amountDue = 0.0;
    }

    public Pet(String type, String name, int age, int daysStay) {
        this.petType = type;
        this.petName = name;
        this.petAge = age;
        this.daysStay = daysStay;
        this.amountDue = 0.0;
    }

    // Getters and Setters (proper encapsulation)

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public int getPetAge() {
        return petAge;
    }

    public void setPetAge(int petAge) {
        this.petAge = petAge;
    }

    public int getDaysStay() {
        return daysStay;
    }

    public void setDaysStay(int daysStay) {
        this.daysStay = daysStay;
    }

    public double getAmountDue() {
        return amountDue;
    }

    public void setAmountDue(double amountDue) {
        this.amountDue = amountDue;
    }

    // =========================
    // Business Logic (ENHANCED)
    // =========================

    public void checkIn() {
        System.out.println(petName + " has been checked in for " + daysStay + " days.");
        calculateAmountDue();
    }

    public void checkOut() {
        System.out.println(petName + " has been checked out.");
        System.out.println("Total due: $" + amountDue);
    }

    public void calculateAmountDue() {
        double ratePerDay = 20.0; // base boarding rate
        amountDue = daysStay * ratePerDay;
    }

    public void displayPetInfo() {
        System.out.println("Pet Name: " + petName);
        System.out.println("Pet Type: " + petType);
        System.out.println("Age: " + petAge);
        System.out.println("Days Staying: " + daysStay);
        System.out.println("Amount Due: $" + amountDue);
    }
}