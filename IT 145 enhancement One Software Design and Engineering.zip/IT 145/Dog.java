public class Dog extends Pet {

    // Dog-specific attributes
    private int dogSpaceNumber;
    private double dogWeight;
    private boolean grooming;

    // Constructor
    public Dog(String name, int age, int daysStay) {
        super("Dog", name, age, daysStay);
    }

    // Getters and Setters

    public int getDogSpaceNumber() {
        return dogSpaceNumber;
    }

    public void setDogSpaceNumber(int dogSpaceNumber) {
        this.dogSpaceNumber = dogSpaceNumber;
    }

    public double getDogWeight() {
        return dogWeight;
    }

    public void setDogWeight(double dogWeight) {
        this.dogWeight = dogWeight;
    }

    public boolean isGrooming() {
        return grooming;
    }

    public void setGrooming(boolean grooming) {
        this.grooming = grooming;
    }

    // =========================
    // Enhanced Business Logic
    // =========================

    @Override
    public void calculateAmountDue() {
        double baseRate = 20.0;
        double groomingFee = grooming ? 10.0 : 0.0;

        setAmountDue((getDaysStay() * baseRate) + groomingFee);
    }

    @Override
    public void checkIn() {
        System.out.println(getPetName() + " (Dog) checked into space #" + dogSpaceNumber);

        if (grooming) {
            System.out.println("Grooming service added.");
        }

        calculateAmountDue();
    }

    @Override
    public void checkOut() {
        System.out.println(getPetName() + " checked out of space #" + dogSpaceNumber);
        System.out.println("Total due: $" + getAmountDue());
    }
}